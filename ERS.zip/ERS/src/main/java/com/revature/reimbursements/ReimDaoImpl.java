package com.revature.reimbursements;

import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Part;

import com.revature.users.User;
import com.revature.util.ConnectionUtil;

public class ReimDaoImpl implements ReimbursementsDao{
	public ReimDaoImpl() {
		
	}
	public void createReim(Reimbursement a) {
		PreparedStatement pstmt = null;
		//ResultSet rs = null;
		CallableStatement getReimId = null;
		
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "INSERT INTO ERS_REIMBURSEMENTS(R_AMOUNT, R_DESCRIPTION,  R_SUBMITTED, U_ID_AUTHOR, RT_TYPE, RT_STATUS) "
					+ "VALUES (?, ?,  ?, ?, ?, ?)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setDouble(1, a.getAmount());
			pstmt.setString(2, a.getDescription());
			//pstmt.setBlob(3, a.getReceipt());
			pstmt.setTimestamp(3, a.getSubmit());
			pstmt.setInt(4, a.getAuthor());
			pstmt.setInt(5, a.getType());
			pstmt.setInt(6, 1);
			
			pstmt.executeQuery();
			pstmt.close();
			//read the id as a result of the trigger/sequence-created id number
			//using stored procedure, take id number and set inside Id of reimbursement
			
			String readId = "{CALL RECEIVE_REIM_ID(?)}";
			getReimId = conn.prepareCall(readId);
			getReimId.registerOutParameter(1, Types.INTEGER);
			
			getReimId.executeUpdate();
			
			a.setId(getReimId.getInt(1));
			getReimId.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void createReim(Reimbursement a, Part pic) {//with picture upload!
		PreparedStatement pstmt = null;
		//ResultSet rs = null;
		CallableStatement getReimId = null;
		
		try(Connection conn = ConnectionUtil.getConnection()){
		String sql = "INSERT INTO ERS_REIMBURSEMENTS(R_AMOUNT, R_DESCRIPTION,  R_SUBMITTED, U_ID_AUTHOR, RT_TYPE, RT_STATUS, R_RECEIPT) "
				+ "VALUES (?, ?,  ?, ?, ?, ?, ?)";
		
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setDouble(1, a.getAmount());
		pstmt.setString(2, a.getDescription());
		//pstmt.setBlob(3, a.getReceipt());
		pstmt.setTimestamp(3, a.getSubmit());
		pstmt.setInt(4, a.getAuthor());
		pstmt.setInt(5, a.getType());
		pstmt.setInt(6, 1);
		pstmt.setBinaryStream(7, pic.getInputStream(), (int) pic.getSize());
		//ps.setBinaryStream(2, photo.getInputStream(), (int)  photo.getSize());
		
		pstmt.executeQuery();
		pstmt.close();
		//read the id as a result of the trigger/sequence-created id number
		//using stored procedure, take id number and set inside Id of reimbursement
		
		String readId = "{CALL RECEIVE_REIM_ID(?)}";
		getReimId = conn.prepareCall(readId);
		getReimId.registerOutParameter(1, Types.INTEGER);
		
		getReimId.executeUpdate();
		
		a.setId(getReimId.getInt(1));
		getReimId.close();
	}catch(SQLException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	}

	public Reimbursement readReim(int id) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Reimbursement result = new Reimbursement();
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "SELECT * FROM ERS_REIMBURSEMENTS WHERE R_ID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
			int newId = rs.getInt("R_ID");
			double newAmount = rs.getDouble("R_AMOUNT");
			String newDes = rs.getString("R_DESCRIPTION");
			Blob newRec = rs.getBlob("R_RECEIPT");
			Timestamp newSub = rs.getTimestamp("R_SUBMITTED");
			Timestamp newRes = rs.getTimestamp("R_RESOLVED");
			int newAuthor = rs.getInt("U_ID_AUTHOR");
			int newResolver = rs.getInt("U_ID_RESOLVER");
			int newType = rs.getInt("RT_TYPE");
			int newStatus = rs.getInt("RT_STATUS");
			
			
			result = new Reimbursement(newId, newAmount, newDes, newRec, newSub, newRes, newAuthor, newResolver, newType, newStatus);
			}
			pstmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public List<Reimbursement> readAllReim() {
		PreparedStatement pstmt = null;
		List<Reimbursement> Reims = new ArrayList<>();
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "SELECT * FROM ERS_REIMBURSEMENTS";
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int newId = rs.getInt("R_ID");
				double newAmount = rs.getDouble("R_AMOUNT");
				String newDes = rs.getString("R_DESCRIPTION");
				Blob newRec = rs.getBlob("R_RECEIPT");
				Timestamp newSub = rs.getTimestamp("R_SUBMITTED");
				Timestamp newRes = rs.getTimestamp("R_RESOLVED");
				int newAuthor = rs.getInt("U_ID_AUTHOR");
				int newResolver = rs.getInt("U_ID_RESOLVER");
				int newType = rs.getInt("RT_TYPE");
				int newStatus = rs.getInt("RT_STATUS");
				
				
				Reimbursement result = new Reimbursement(newId, newAmount, newDes, newRec, newSub,
						newRes, newAuthor, newResolver, newType, newStatus);
				Reims.add(result);
				
			}
			pstmt.close();
			rs.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return Reims;
	}
	public void updateReim(Reimbursement a) {
		PreparedStatement pstmt = null;
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "UPDATE ERS_REIMBURSEMENTS  R_AMOUNT = ?, R_DESCRIPTION = ?,"
					+ " R_RECIPT = ?, R_SUBMITTED = ?, R_RESOLVED = ?, U_ID_AUTHOR = ?, U_ID_RESOLVER = ?, "
					+ "RT_TYPE = ?, RT_STATUS = ? WHERE R_ID = ?"; 
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setDouble(1,  a.getAmount());
			pstmt.setString(2, a.getDescription());
			pstmt.setBlob(3, a.getReceipt());
			pstmt.setTimestamp(4, a.getSubmit());
			pstmt.setTimestamp(5, a.getResolve());
			pstmt.setInt(6, a.getAuthor());
			pstmt.setInt(7, a.getResolver());
			pstmt.setInt(8, a.getType());
			pstmt.setInt(9, a.getStatus());
			pstmt.setInt(10, a.getId());
			
			pstmt.execute();
			pstmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	public void deleteReim(Reimbursement a) {
		PreparedStatement pstmt = null;
		try(Connection conn =ConnectionUtil.getConnection()){
			String sql = "DELETE FROM ERS_REIMBURSEMENTS WHERE R_ID = ?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, a.getId());
			pstmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}


	@Override
	public List<Reimbursement> readAllPending() {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Reimbursement> Reims = new ArrayList<>();
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "SELECT * FROM ERS_REIMBURSEMENTS WHERE RT_STATUS = 1";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int newId = rs.getInt("R_ID");
				double newAmount = rs.getDouble("R_AMOUNT");
				String newDes = rs.getString("R_DESCRIPTION");
				Blob newRec = rs.getBlob("R_RECEIPT");
				Timestamp newSub = rs.getTimestamp("R_SUBMITTED");
				Timestamp newRes = rs.getTimestamp("R_RESOLVED");
				int newAuthor = rs.getInt("U_ID_AUTHOR");
				int newResolver = rs.getInt("U_ID_RESOLVER");
				int newType = rs.getInt("RT_TYPE");
				int newStatus = rs.getInt("RT_STATUS");
				
				Reimbursement result = new Reimbursement(newId, newAmount, newDes, newRec, newSub,
						newRes, newAuthor, newResolver, newType, newStatus);
				Reims.add(result);
				
			}
			pstmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return Reims;
	}

	@Override
	public List<Reimbursement> readAllUserPending(int id) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Reimbursement> reims = new ArrayList<>();
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "SELECT * FROM ERS_REIMBURSEMENTS WHERE U_ID_AUTHOR = ? AND RT_STATUS = 1";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int newId = rs.getInt("R_ID");
				double newAmount = rs.getDouble("R_AMOUNT");
				String newDes = rs.getString("R_DESCRIPTION");
				Blob newRec = rs.getBlob("R_RECEIPT");
				Timestamp newSub = rs.getTimestamp("R_SUBMITTED");
				Timestamp newRes = rs.getTimestamp("R_RESOLVED");
				int newAuthor = rs.getInt("U_ID_AUTHOR");
				int newResolver = rs.getInt("U_ID_RESOLVER");
				int newType = rs.getInt("RT_TYPE");
				int newStatus = rs.getInt("RT_STATUS");
				
				Reimbursement result = new Reimbursement(newId, newAmount, newDes, newRec, newSub,
						newRes, newAuthor, newResolver, newType, newStatus);
				reims.add(result);
			}
			pstmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return reims;
	}

	@Override
	public List<Reimbursement> readAllResolved() {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Reimbursement> reims = new ArrayList<>();
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "SELECT * FROM ERS_REIMBURSEMENTS WHERE RT_STATUS = 2 OR RT_STATUS = 3";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int newId = rs.getInt("R_ID");
				double newAmount = rs.getDouble("R_AMOUNT");
				String newDes = rs.getString("R_DESCRIPTION");
				Blob newRec = rs.getBlob("R_RECEIPT");
				Timestamp newSub = rs.getTimestamp("R_SUBMITTED");
				Timestamp newRes = rs.getTimestamp("R_RESOLVED");
				int newAuthor = rs.getInt("U_ID_AUTHOR");
				int newResolver = rs.getInt("U_ID_RESOLVER");
				int newType = rs.getInt("RT_TYPE");
				int newStatus = rs.getInt("RT_STATUS");
				
				Reimbursement result = new Reimbursement(newId, newAmount, newDes, newRec, newSub,
						newRes, newAuthor, newResolver, newType, newStatus);
				reims.add(result);
			}
			pstmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return reims;
	}

	@Override
	public List<Reimbursement> readAllUserResolved(int id) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Reimbursement> reims = new ArrayList<>();
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "SELECT * FROM ERS_REIMBURSEMENTS WHERE U_ID_AUTHOR = ? AND RS_STATUS = 2 OR RS_STATUS = 3";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int newId = rs.getInt("R_ID");
				double newAmount = rs.getDouble("R_AMOUNT");
				String newDes = rs.getString("R_DESCRIPTION");
				Blob newRec = rs.getBlob("R_RECEIPT");
				Timestamp newSub = rs.getTimestamp("R_SUBMITTED");
				Timestamp newRes = rs.getTimestamp("R_RESOLVED");
				int newAuthor = rs.getInt("U_ID_AUTHOR");
				int newResolver = rs.getInt("U_ID_RESOLVER");
				int newType = rs.getInt("RT_TYPE");
				int newStatus = rs.getInt("RT_STATUS");
				
				Reimbursement result = new Reimbursement(newId, newAmount, newDes, newRec, newSub,
						newRes, newAuthor, newResolver, newType, newStatus);
				reims.add(result);
			}
			pstmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return reims;
	}

}
