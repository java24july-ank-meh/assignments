package com.revature.reimbursements;

import java.sql.*;

public class Reimbursement {
	//types
	public final static int BUSINESS = 1;
	public final static int EDUCATION = 2;
	public final static int FAMILY = 3;
	public final static int TRAVEL = 4;
	
	//statuses
	public final static int PENDING = 1;
	public final static int APPROVED = 2;
	public final static int DENIED = 3;
	
	private int id;
	private double amount;
	private String description;
	private Blob receipt;
	private Timestamp submit;
	private Timestamp resolve;
	private int author;
	private int resolver;
	private int type;
	private int status;
	
	public Reimbursement() {
		status = PENDING;
		submit = new Timestamp(System.currentTimeMillis());
	}
	
	public String translateType() {
		switch(type) {
		case BUSINESS: return "Business";
		case EDUCATION: return "Education";
		case FAMILY: return "Family";
		case TRAVEL: return "Travel";
		default: return null;
		}
	}
	
	public String translateStatus() {
		switch(status) {
		case PENDING: return "Pending";
		case APPROVED: return "Approved";
		case DENIED: return "Denied";
		default: return null;
		}
	}
	
	@Override
	public String toString() {
		return "Reimbursement [id=" + id + ", amount=" + amount + ", description=" + description + ", receipt="
				+ receipt + ", submit=" + submit + ", resolve=" + resolve + ", author=" + author + ", resolver="
				+ resolver + ", type=" + type + ", status=" + status + "]";
	}

	public Reimbursement(int id, double amount, String description, Blob receipt, Timestamp submit, Timestamp resolve,
			int author, int resolver, int type, int status) {
		super();
		this.id = id;
		this.amount = amount;
		this.description = description;
		this.receipt = receipt;
		this.submit = submit;
		this.resolve = resolve;
		this.author = author;
		this.resolver = resolver;
		this.type = type;
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescritption(String description) {
		this.description = description;
	}
	public Blob getReceipt() {
		return receipt;
	}
	public void setReceipt(Blob receipt) {
		this.receipt = receipt;
	}
	public Timestamp getSubmit() {
		return submit;
	}
	public void setSubmit(Timestamp submit) {
		this.submit = submit;
	}
	public Timestamp getResolve() {
		return resolve;
	}
	public void setResolve(Timestamp resolve) {
		this.resolve = resolve;
	}
	public int getAuthor() {
		return author;
	}
	public void setAuthor(int author) {
		this.author = author;
	}
	public int getResolver() {
		return resolver;
	}
	public void setResolver(int resolver) {
		this.resolver = resolver;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	
}
