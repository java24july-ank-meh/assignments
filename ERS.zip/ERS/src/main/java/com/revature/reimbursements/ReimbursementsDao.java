package com.revature.reimbursements;

import java.util.List;

import com.revature.users.User;

public interface ReimbursementsDao {
	public void createReim(Reimbursement a);
	public Reimbursement readReim(int id);
	public List<Reimbursement> readAllPending();
	public List<Reimbursement> readAllUserPending(int id);
	public List<Reimbursement> readAllResolved();
	public List<Reimbursement> readAllUserResolved(int id);
	public void updateReim(Reimbursement a);
	public void deleteReim(Reimbursement a);
}
