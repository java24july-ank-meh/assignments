package com.revature.main;


import java.util.Date;
import java.sql.Timestamp;
import java.text.DateFormat;


import com.revature.reimbursements.*;
import com.revature.users.*;
public class TestMain {
	public static void main(String[] args) {
		UsersDaoImpl userThings = new UsersDaoImpl();
		ReimDaoImpl reims = new ReimDaoImpl();
		
		Timestamp timestamp =  new Timestamp(System.currentTimeMillis());
		
		
		
		
		User dan = new User();
//		User holly = new User();
		
//		holly.setEmail("duhgirl@mail.com");
//		holly.setFirstName("Commander");
//		holly.setLastName("Holly");
//		holly.setUserName("duhGirl");
//		holly.setPassword("barrynotross");
//		holly.setUr_id(2);
//		System.out.println("created user object");
//		
//		userThings.createUser(holly);
//		System.out.println(holly.getId());
		
		dan.setFirstName("Dan");
		dan.setLastName("Avidan");
		dan.setEmail("dannyboy@mail.com");
		dan.setUserName("NotSoGrump");
		dan.setPassword("arin");
		dan.setUr_id(3);
		dan.setId(33);
//		System.out.println("created the object");
//		userThings.createUser(dan);
//		System.out.println(dan.getId());
		//userThings.deleteUser(dan);
		//System.out.println(dan.getId());
		
		User readDan = userThings.readUser(dan);
		
		Reimbursement danTravel = new Reimbursement();
		danTravel.setAmount(100.50);
		int danId = dan.getId();
		System.out.println(danId);
		danTravel.setAuthor(readDan.getId());
		
//		System.out.println(danTravel.getAuthor());
//		danTravel.setDescritption("Hotel and board");
//		danTravel.setSubmit(timestamp);
//		danTravel.setStatus(1);
//		danTravel.setType(4);
//		System.out.println("created reim object");
//		reims.createReim(danTravel);
//		System.out.println(danTravel.getId());
		
		Reimbursement returnDanTravel = new Reimbursement();
		reims.readReim(returnDanTravel);
		System.out.println(returnDanTravel);
	}
}
