package com.revature.users;

public class AppUser {
	private static User user;
	
	public AppUser() {
		if(user == null) {
			user = new User();	
		}
	}
	
	public AppUser(User inUser) {
		user = new User(inUser);
	}
	
	public User getUser() {
		return user;
	}
	
	public void logout() {
		user.setEmail("");
		user.setFirstName("");
		user.setId(0);
		user.setLastName("");
		user.setPassword("");
		user.setUr_id(0);
		user.setUserName("");
		user = null;
	}
}
