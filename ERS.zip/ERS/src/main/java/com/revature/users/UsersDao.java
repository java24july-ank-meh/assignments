package com.revature.users;

import java.util.List;

public interface UsersDao {
	public  void createUser(User u);
	public User readUser(User u);
	public List<User> readAllUsers();
	public void updateUser(User u);
	public void deleteUser(User u);
	public boolean doesExist(String uName, int typeCheck);
}
