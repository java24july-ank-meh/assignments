package com.revature.users;

public class User {
	public static int EMPLOYEE = 3;
	public static int MANAGER = 2;
	public static int ADMIN = 1;
	
	private int id;
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private int ur_id;
	
	public User() {
		
	}
	public User(int id, String userName, String password, String firstName, String lastName, String email, int ur_id) {
		super();
		this.id = id;
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.ur_id = ur_id;
	}
	
	public User(User u) {
		this(u.id, u.userName, u.password, u.firstName, u.lastName, u.email, u.ur_id);
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getUr_id() {
		return ur_id;
	}
	public void setUr_id(int ur_id) {
		this.ur_id = ur_id;
	}
}
