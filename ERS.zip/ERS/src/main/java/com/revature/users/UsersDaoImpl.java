package com.revature.users;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.revature.util.ConnectionUtil;

public class UsersDaoImpl implements UsersDao {
	
	public final int USERNAME = 1;
	public final int EMAIL = 2; 
	
	public UsersDaoImpl(){
		
	}
	@Override
	public  void createUser(User u) {
		PreparedStatement pstmt = null;
	
		
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "INSERT INTO ERS_USERS (U_USERNAME, U_PASSWORD, U_FIRSTNAME, U_LASTNAME, U_EMAIL, UR_ID)"
					+ " VALUES (?, ?, ?, ?, ?, ?)";
			
			pstmt = conn.prepareStatement(sql);
			//System.out.println("preparedStatment");
			
			pstmt.setString(1, u.getUserName());
			pstmt.setString(2, u.getPassword());
			pstmt.setString(3, u.getFirstName());
			pstmt.setString(4, u.getLastName());
			pstmt.setString(5, u.getEmail());
			pstmt.setInt(6, u.getUr_id());
			//System.out.println("set the items");
			
			pstmt.execute();
			pstmt.close();
			
			//System.out.println("Created person in database");
		
//			
//			//receiving the id and putting it in person
//			
//	
		}catch(SQLException e) {
			e.printStackTrace();
			
		}finally {if(pstmt != null) {try { pstmt.close();} catch(SQLException e) {e.printStackTrace();}}
			
		}
		
		PreparedStatement getUserId = null;
		ResultSet returnedUser = null;
		try(Connection conn = ConnectionUtil.getConnection()){
			String readInt = "SELECT * FROM ERS_USERS WHERE U_USERNAME = ?";
			getUserId = conn.prepareStatement(readInt);
			getUserId.setString(1, u.getUserName());
			
			returnedUser = getUserId.executeQuery();
			returnedUser.next();
			int newId = returnedUser.getInt("U_ID");
			u.setId(newId);
			getUserId.close();
			returnedUser.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {if(getUserId != null) {try { getUserId.close();} catch(SQLException e) {e.printStackTrace();}}
			{if(returnedUser !=null) {try {returnedUser.close();} catch(SQLException e) {e.printStackTrace();}}
			}
		}
		
	}

	@Override
	public User readUser(User u) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		User result = new User();
		try(Connection conn =ConnectionUtil.getConnection()){
			String sql = "SELECT * FROM ERS_USERS WHERE U_ID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, u.getId());
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
			int newId = rs.getInt("U_ID");
			System.out.println(newId);
			String newUserName = rs.getString("U_USERNAME");
			String newPassword = rs.getString("U_PASSWORD");
			String newFirstName = rs.getString("U_FIRSTNAME");
			String newLastName = rs.getString("U_LASTNAME");
			String newEmail = rs.getString("U_EMAIL");
			int newUrId = rs.getInt("UR_ID");
			result = new User(newId, newUserName, newPassword, newFirstName, newLastName, newEmail, newUrId);
			}
			pstmt.close();
			rs.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	public List<User> readAllUsers() {
		PreparedStatement pstmt = null;
		List<User> users = new ArrayList<>();
		try(Connection conn = ConnectionUtil.getConnection()){
			
			String sql = "SELECT * FROM ERS_USERS";
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int newId = rs.getInt("U_ID");
				String newUserName = rs.getString("U_USERNAME");
				String newPassword = rs.getString("U_PASSWORD");
				String newFirstName = rs.getString("U_FIRSTNAME");
				String newLastName = rs.getString("U_LASTNAME");
				String newEmail = rs.getString("U_EMAIL");
				int newUrId = rs.getInt("UR_ID");
				
				User result = new User(newId, newUserName, newPassword, newFirstName, newLastName, newEmail, newUrId);
				users.add(result);
			}
			pstmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	/**
	 * This method checks the given username and password and tries to see if the login information is correct.
	 * If the login information is correct, the AppUser.user is properly set for this.
	 * @param username the username that the website user input
	 * @param password the password that the website user input
	 * @return true if login was successful and false otherwise
	 */
	public boolean attemptLogin(String username, String password) {
		List<User> users = readAllUsers();
		for(User user : users) {
			if(username.equals(user.getUserName()) && password.equals(user.getPassword())) {
				//sets the AppUser.user object to what it needs to be through the constructor itself
				AppUser appUser = new AppUser(user);
				return true;
			}
		}
		return false;
	}

	@Override
	public void updateUser(User u) {
		PreparedStatement pstmt = null;
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "UPDATE ERS_USERS U_USERNAME = ?, U_PASSWORD = ?, U_FIRSTNAME = ?, U_LASTNAME = ?, U_EMAIL = ?, "
					+ "UR_ID = ? WHERE U_ID = ?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, u.getUserName());
			pstmt.setString(2, u.getPassword());
			pstmt.setString(3,  u.getFirstName());
			pstmt.setString(4, u.getLastName());
			pstmt.setString(5, u.getEmail());
			pstmt.setInt(6, u.getUr_id());
			pstmt.setInt(7, u.getId());
			
			pstmt.executeQuery();
			pstmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteUser(User u) {
		PreparedStatement pstmt = null;
		try(Connection conn = ConnectionUtil.getConnection()){
			String sql = "DELETE * FROM ERS_USERS WHERE U_ID = ?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, u.getId());
			pstmt.execute();
			pstmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public boolean doesExist(String check, int type) {
		List<User> users = readAllUsers();
		for(User user : users) {
			if(type == USERNAME && user.getUserName().equals(check)) return true;
			else if(type == EMAIL && user.getEmail().equals(check)) return true;
		}
		return false;
	}

	
}
