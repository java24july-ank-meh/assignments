package com.revature.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.revature.reimbursements.ReimDaoImpl;
import com.revature.reimbursements.Reimbursement;
import com.revature.users.AppUser;
import com.revature.users.User;

/**
 * Servlet implementation class UserViewRequest
 */
public class UserViewRequest extends ControllerServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserViewRequest() {
        super();
        // TODO Auto-generated constructor stub
    }

    /* Handled html patterns:
     * /UserViewRequest - standard view requests
     * /UploadRequest - upload a user's requests and then show them the standard view requests page*/
    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) {
    	try (PrintWriter out = resp.getWriter()) {
    		String userPath = req.getServletPath();
    		AppUser appUser = new AppUser();
    		User user = appUser.getUser();
    		ReimDaoImpl tempDAO = new ReimDaoImpl();
    		
    		makePageTop(out, userPath);
    		
    		switch(userPath) {
    		case "/UploadRequest": //there is no break because we want the normal page to show after adding the new request to the database
    			double amountIn = Double.parseDouble(req.getParameter("amountIn"));
    			String descriptionIn = req.getParameter("descriptionIn");
    			int typeIn = Integer.parseInt(req.getParameter("typeIn").trim());
    			Part pictureIn = req.getPart("pictureIn");
    			
    			Reimbursement r = new Reimbursement();
    			r.setAmount(amountIn);
    			r.setDescritption(descriptionIn);
    			r.setType(typeIn);
    			r.setSubmit(new Timestamp(System.currentTimeMillis()));
    			r.setAuthor(user.getId());
    			
    			tempDAO.createReim(r, pictureIn);
    			//no break so we get the page printed off
    			
    		case "UserViewRequest": //give the page of requests
    			List<Reimbursement> tableList = tempDAO.readAllUserPending(user.getId());
    			out.println("<section id=\"boxes\">\r\n" + 
    					"        <div class=\"container\">\r\n" + 
    					"            <div class=\"box\">\r\n" + 
    					"                <h1>Pending requests</h1>\r\n" + 
    					"                <table class=\"prettyTable\">");
    			
    			for(Reimbursement thing : tableList) {
        			out.println("<tr>");
        			out.println("<th>$" + thing.getAmount() + "</th>");
        			out.println("<th>" + thing.translateType() + "</th>");
        			out.println("<th>" + thing.getSubmit() + "</th>");
        			out.println("</tr>");
        		}
    			
    			out.println("</table>\r\n" + 
    					"            </div>\r\n" + 
    					"            <div class=\"box\">\r\n" + 
    					"                <h1>Resolved requests</h1>\r\n" + 
    					"                <table class=\"prettyTable\">");
    			
    			tableList = tempDAO.readAllResolved();
        		
        		for(Reimbursement thing : tableList) {
        			out.println("<tr>");
        			out.println("<th>$" + thing.getAmount() + "</th>");
        			out.println("<th>" + thing.translateType() + "</th>");
        			out.println("<th>" + thing.getResolve() + "</th>");
        			out.println("<th>" + thing.translateStatus() + "</th>");
        			out.println("</tr>");
        		}
        		
        		out.println("</table>\r\n" + 
        				"            </div>\r\n" + 
        				"\r\n" + 
        				"        </div>\r\n" + 
        				"    </section>");
    			
    			
    			makePageBottom(out);
    			
    			
    		}
    		
    	} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
