package com.revature.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.users.AppUser;
import com.revature.users.User;
import com.revature.reimbursements.*;;

public class UserSessionServlet extends ControllerServlet {
	
	protected void processRequest(HttpServletRequest req, HttpServletResponse resp) {
		try (PrintWriter out = resp.getWriter()) {
    		AppUser appUser = new AppUser();
    		User user = appUser.getUser();
    		ReimDaoImpl tempDAO = new ReimDaoImpl();
    		
    		makePageTop(out, req.getServletPath());
    		
    		//make table for pending requests
    		List<Reimbursement> tableList = tempDAO.readAllUserPending(user.getId());
    		out.println("<section id=\"boxes\">\r\n" + 
    				"                <div class=\"container\">\r\n" + 
    				"                    <div class=\"box\">\r\n" + 
    				"                        <h1>Pending requests</h1>\r\n" + 
    				"                        <table class=\"prettyTable\">");
    		
    		int count = 0;
    		
    		for(Reimbursement thing : tableList) {
    			if(count == 5) break; //only print off the first 5 for this page
    			out.println("<tr>");
    			out.println("<th>$" + thing.getAmount() + "</th>");
    			out.println("<th>" + thing.translateType() + "</th>");
    			out.println("<th>" + thing.getSubmit() + "</th>");
    			out.println("</tr>");
    			count++;
    		}
    		
    		
    		//next we put in the resolved requests in
    		out.println("</table>\r\n" + 
    				"                        <label><a href=\"/ERS/UserViewRequest\">View all</a></label>\r\n" + 
    				"                    </div>\r\n" + 
    				"                    <div class=\"box\">\r\n" + 
    				"                        <h1>Resolved requests</h1>\r\n" + 
    				"                        <table class=\"prettyTable\">");
    		
    		tableList = tempDAO.readAllResolved();
    		
    		count = 0; //reset the counter
    		for(Reimbursement thing : tableList) {
    			if(count == 5) break; //only print off the first 5 for this page
    			out.println("<tr>");
    			out.println("<th>$" + thing.getAmount() + "</th>");
    			out.println("<th>" + thing.translateType() + "</th>");
    			out.println("<th>" + thing.getResolve() + "</th>");
    			out.println("<th>" + thing.translateStatus() + "</th>");
    			out.println("</tr>");
    			count++;
    		}
    		
    		out.println("</table>\r\n" + 
    				"                <label><a href=\"/ERS/UserViewRequest\">View all</a></label>\r\n" + 
    				"            </div>\r\n" + 
    				"            <div class=\"box\">\r\n" + 
    				"                <form action=\"/ERS/UploadRequest\">\r\n" + 
    				"                    <h1>Submit a new request</h1>\r\n" + 
    				"                    <label style=\"width: auto; font-size: 18px\">Request amount</label>\r\n" + 
    				"                    <input name=\"amountIn\" />\r\n" + 
    				"                    <br />\r\n" + 
    				"                    <label style=\"width: auto; font-size: 18px\">Request description</label>\r\n" + 
    				"                    <input name=\"descriptionIn\" />\r\n" + 
    				"                    <br />\r\n" + 
    				"                    <label style=\"width: auto; font-size: 18px\">Request type</label>\r\n" + 
    				"                    <select name=\"typeIn\">\r\n" + 
    				"                            <option value=\"" + Reimbursement.TRAVEL + "\">Travel</option>\r\n" + 
    				"                            <option value=\"" + Reimbursement.BUSINESS + " \">Business</option>\r\n" + 
    				"                            <option value=\"" + Reimbursement.FAMILY + "\">Family</option>\r\n" + 
    				"                            <option value=\"" + Reimbursement.EDUCATION + "\">Education</option>\r\n" + 
    				"                        </select>\r\n" + 
    				"                    <br />\r\n" + 
    				"                    <label style=\"width: auto; font-size: 18px\">Reciept upload</label>\r\n" + 
    				"\r\n" + 
    				"                    <!-- screw gifs! -->\r\n" + 
    				"                    <input type=\"file\" name=\"pictureIn\" name=\"picture\" accept=\"image/gif, image/jpeg\" size=\"1000\">\r\n" +
    				"                    <br />\r\n" + 
    				"                    <input type=\"submit\" value=\"Submit new request\" class=\"btn btn-info\" />\r\n" + 
    				"                </form>\r\n" + 
    				"            </div>\r\n" + 
    				"        </div>\r\n" + 
    				"    </section>");
    		
    		makePageBottom(out);
    		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}
	
	@Override 
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		processRequest(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		processRequest(req, resp);
	}
}
