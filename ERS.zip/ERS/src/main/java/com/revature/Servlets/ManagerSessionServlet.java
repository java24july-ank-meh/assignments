package com.revature.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import com.revature.reimbursements.ReimDaoImpl;
import com.revature.reimbursements.Reimbursement;
import com.revature.users.User;
import com.revature.users.UsersDaoImpl;

public class ManagerSessionServlet extends ControllerServlet{
	private static final long serialVersionUID = 1L;
	
	public ManagerSessionServlet() {
		super();
	}
	
	protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		try(PrintWriter out = resp.getWriter()){
			makePageTop(out, req.getServletPath());
			makeReimView(out, req);
		}
	}
	@Override
	protected void doGet(HttpServletRequest req,  HttpServletResponse resp) throws ServletException, IOException{
		processRequest(req, resp);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		processRequest(req, resp);
	}
	
	protected void makeReimView(PrintWriter out, HttpServletRequest req) {
		ReimDaoImpl reimDao = new ReimDaoImpl();
		  UsersDaoImpl userDao = new UsersDaoImpl();
		  
		  //pending reimbursements are shown first
		  List<Reimbursement> reimsPending = reimDao.readAllPending();
		  List<Reimbursement> reimsResolved = reimDao.readAllResolved();
		  
		  out.println(" <div class=\"box\">\r\n" + 
		  		"                <h1>Requests</h1>\r\n" + 
		  		"                <table class=\"prettyTable\">\r\n" + 
		  		"");
		  
		  int counter = 0;
		  for(Reimbursement reim : reimsPending) {
					  if (counter == 5) {break;};
					  //assigning author name
					  List<User> possibleAuthors = userDao.readAllUsers();
					  User author = new User();
					  author.setId(reim.getAuthor());
					  for(User posAuthor : possibleAuthors) {
						  if(author.getId() == posAuthor.getId()) {
							  author.setFirstName(posAuthor.getFirstName());
							  author.setLastName(posAuthor.getLastName());
						  }
					  }
					  
					  out.println(" <tr>\r\n" + 
					  		"						<th>"+ author.getFirstName()+ " "+ author.getLastName()+"</th>\r\n" + 
					  		"                        <th>"+reim.getAmount()+" </th>\r\n" + 
					  		"                        <th>"+reim.getType()+"</th>\r\n" + 
					  		"                        <th>"+ reim.getSubmit() +"</th>\r\n" + 
					  	
					  	 
					  							
					  		"                    </tr>");
					  counter++;
		  }
		  
		  out.println("       </table>\r\n" + 
									
		  		"                        <label><a href=\"ManagerViewRequests\">View all</a></label>\r\n" + 
		  		"                    </div>");
		  
		  //box for employee preview
		  
		  UsersDaoImpl tempDao = new UsersDaoImpl();
			List<User> userList = tempDao.readAllUsers();
			out.println("<div class=\"box\">\r\n" + 
					"                <h1>Employees</h1>\r\n" + 
					"                <table class=\"prettyTable\">\r\n" + 
					"");
					int empCounter = 0;
					for (User user:userList) {
						if(empCounter ==5) {break;}
						out.println("  <tr>\r\n" + 
								"                        <th>>"+ user.getUserName() +"</th>\r\n" + 
								"                        <th>" + user.getFirstName() + "</th>\r\n" + 
								"                        <th>" + user.getLastName() + "</th>\r\n" + 
								"                    </tr>");
						empCounter++;
					}
					
					out.println("                </table>\r\n" + 
							"				<label><a href=\"ManagerViewEmployees\">View All</a></label>"+				
							"            </div>\r\n" + 
							"</body>\r\n" + 
							"</html>");
					
		}
}
