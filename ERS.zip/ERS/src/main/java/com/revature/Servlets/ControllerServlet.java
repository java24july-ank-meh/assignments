package com.revature.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.print.event.PrintJobAdapter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.users.AppUser;
import com.revature.users.User;

/**
 * Servlet implementation class ControllerServlet
 */


public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    

	protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		
	}
	
	protected void makePageTop(PrintWriter out, String userPath) throws ServletException, IOException {
		
		out.println("<!DOCTYPE html>");
		out.println("<html xmlns = \"http://www.w3.org/1999/xhtml\">");
		out.println("<head>");
		
		makeHead(out, userPath);
		
		makeHeader(out, userPath);
		
	}
	
	protected void makePageBottom(PrintWriter out) throws ServletException, IOException{
		out.println("</body>\r\n" + 
				"\r\n" + 
				"<script src=\"https://code.jquery.com/jquery-2.2.4.min.js\"></script>\r\n" + 
				"<script src=\"https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js\"></script>\r\n" + 
				"<script src=\"javascript/script.js\"></script>\r\n" + 
				"\r\n" + 
				"</html>");
	}

	protected void setPageTitle(PrintWriter out, String userPath) throws ServletException, IOException{
		if(userPath.equals("/employeeshome")) {
			out.println("<title>Employee Home Page</title>");
		}else if (userPath.equals("/managerSession")) {
			out.println("<title>Manager Home Page</title>");
		}else if(userPath.equals("/UserViewRequest")) {
			out.println("<title>Viewing Requests</title>");
			
		}else if(userPath.equals("/ManagerViewEmployees")) {
			out.println("<title>Viewing Employees</title>");
		}else if(userPath.equals("/ProfileChanger")) {
			out.println("<title>Changing Profile</title>");
		}else if(userPath.equals("/LoginSession") || userPath.equals("LogUserIn")
				|| userPath.equals("/LogUserOut")) {
			out.println("<title>Login</title>");
		}else if(userPath.equals("/RegisterHere") || userPath.equals("/RegisterNewUser")) {
			out.println("<title>Register</title>");
		}
		
		else {
			out.println("404 error");
		}
	}
	
	protected void makeHead(PrintWriter out, String userPath) throws ServletException, IOException {
		setPageTitle(out, userPath);
		out.println("<link rel=\"stylesheet\" href=\"css/boxStyle.css\">");
		out.println("<link rel=\"stylesheet\" href=\"css/style.css\">");
		out.println("<meta name=\"author\" content=\"Nora and Julia\">");
		out.println("<meta name=\"viewport\" content=\"width=device-width\">");
		out.println("<meta charset=\"utf-8\">");
		out.println("</head>");
		
		
	}
	

	private void makeHeader(PrintWriter out, String userPath) {
		out.println("<body>\r\n" + 
				"\r\n" + 
				"    <header>\r\n" + 
				"        <div class=\"container\">\r\n" + 
				"            <div id=\"branding\">\r\n" + 
				"                <h1><a href=\"index.html\"><span class=\"highlight\">Reimbursement</span> Stuff</a></h1>\r\n" + 
				"            </div>\r\n" + 
				"        </div>\r\n" + 
				"        <nav class=\"container\">\r\n" + 
				"            <ul>");
		
		if(userPath.equals("/LoginSession") || userPath.equals("/LogUserIn")
				|| userPath.equals("/RegisterHere") || userPath.equals("/RegisterNewUser")) {
			out.println("<li><a href=\"/ERS/LoginSession\">Login</a></li>\r\n" + 
					"                <li><a href=\"/ERS/RegisterHere\">register</a></li>");
		} else {
			AppUser appUser = new AppUser();
			User user = appUser.getUser();
			
			out.println("<li>Hello there <a href=\"/ERS/ProfileChanger\">" + user.getUserName() + "</a></li>\r\n" + 
					"                <li><a href=\"/ERS/LogUserOut\">Logout</a></li>");
		}
		
		out.println("</ul>\r\n" + 
				"        </nav>\r\n" + 
				"    </header>");
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
