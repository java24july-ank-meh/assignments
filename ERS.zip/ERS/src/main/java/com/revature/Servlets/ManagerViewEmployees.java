package com.revature.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.reimbursements.ReimDaoImpl;
import com.revature.users.AppUser;
import com.revature.users.User;
import com.revature.users.UsersDaoImpl;


public class ManagerViewEmployees extends ControllerServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ManagerViewEmployees() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
    	try(PrintWriter out = resp.getWriter()){
    		AppUser appUser = new AppUser();
    		//User user = appUser.getUser();
    		
    		//UsersDaoImpl tempDao = new UsersDaoImpl();
    		//ReimDaoImpl tempReimDao = new ReimDaoImpl();
    		
    		makePageTop(out, req.getServletPath());
    		printEmployeeView(out);
    		
    	}catch (IOException e) {
    		e.printStackTrace();
    	}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	private void printEmployeeView(PrintWriter out) {
		UsersDaoImpl tempDao = new UsersDaoImpl();
		List<User> userList = tempDao.readAllUsers();
		out.println("<div class=\"box\">\r\n" + 
				"                <h1>Employees</h1>\r\n" + 
				"                <table class=\"prettyTable\">\r\n" + 
				"");
		
				for (User user:userList) {
					out.println("  <tr>\r\n" + 
							"                        <th><a href=\"EMPLOYEEREQUESTS\">"+ user.getUserName() +"</a></th>\r\n" + 
							"                        <th>" + user.getFirstName() + "</th>\r\n" + 
							"                        <th>" + user.getLastName() + "</th>\r\n" + 
							"                    </tr>");
				}
				out.println("                </table>\r\n" + 
						"            </div>\r\n" + 
						"</body>\r\n" + 
						"</html>");
				
	}
	
	
}