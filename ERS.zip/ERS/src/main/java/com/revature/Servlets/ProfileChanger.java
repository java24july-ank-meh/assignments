package com.revature.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.users.AppUser;
import com.revature.users.User;
import com.revature.users.UsersDaoImpl;

/**
 * Servlet implementation class ProfileChanger
 */
public class ProfileChanger extends ControllerServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProfileChanger() {
        super();
        // TODO Auto-generated constructor stub
    }

    /* handled url patterns:
     * /ProfileChanger - normal page for changing the profile information
     * /ChangeMyProfile - actually takes in the stuff from the request to change the user information
     * in the database, updates the AppUser.user object, and then gives the new page with all of the
     * updated information on it and the same options to update if wanted. */
    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException {
    	try (PrintWriter out = resp.getWriter()) {
    		String userPath = req.getServletPath();
    		AppUser appUser = new AppUser();
    		User user = appUser.getUser();
    		/* tempUser is set up to have all the same values as normal user to start so we can alter it
    		 * without altering the AppUser.user data until after we know that all of the changes are going
    		 * to actually go through. */
    		User tempUser = new User(user);
    		
    		UsersDaoImpl tempDAO = new UsersDaoImpl();
    		
    		makePageTop(out, userPath);
    		
    		switch(userPath) {
    		case "/ChangeMyProfile": //actually change the profile information
    			/* Note that there is no break at the end of this case. After this is done we will
    			 * print off the page as normal.*/
    			boolean passChangeGood = false;
    			boolean usernameChangeGood = false;
    			boolean emailChangeGood = false;
    			/*NOTE: by default, all of the fields for changing a user's information are set to be equal to
    			 * what the current value of that is so that we can just always use the values that are in the
    			 * fields, even when there is not going to actually be a change in the information.
    			 */
    			
    			//get all input fields as Strings for use through the rest of this method
    			String emailIn = req.getParameter("emailIn");
    			String usernameIn = req.getParameter("usernameIn");
    			String firstNameIn = req.getParameter("firstNameIn");
    			String lastNameIn = req.getParameter("lastNameIn");
    			String currentPass = req.getParameter("currentPassword");
    			String newPass = req.getParameter("newPassword");
    			String conNewPass = req.getParameter("confirmNewPassword");
    			
    			
    			
    			//check to make sure that the username is not taken if the user is trying to change that
    			if(!user.getUserName().equals(usernameIn)) {
    				usernameChangeGood = !tempDAO.doesExist(usernameIn, tempDAO.USERNAME);
    				if(usernameChangeGood) tempUser.setUserName(usernameIn);
    			} else {
    				// the user does not want to change the username so we don't need to do anything
    				usernameChangeGood = true;
    			}
    			
    			//check to make sure that the email the user wants to change too is not already associated with
    			//an account if they want to change emails
    			if(!user.getEmail().equals(emailIn)) {
    				emailChangeGood = !tempDAO.doesExist(emailIn, tempDAO.EMAIL);
    				if(emailChangeGood) tempUser.setEmail(emailIn);
    			} else {
    				//the user does not want to change emails so all is good
    				emailChangeGood = true;
    			}
    			
    			//if at least one of the password fields is not empty string, go through
    			//the checks to change the user password
    			if(!currentPass.equals("") || !newPass.equals("") || !conNewPass.equals("")) {
    				//Go through the process of checking to see if the new password should be accepted or not
    				emailChangeGood = currentPass.equals(user.getPassword()) && newPass.equals(conNewPass);
    				if(emailChangeGood) tempUser.setPassword(newPass);
    			} else {
    				//the user does not want to change their email so all is good
    				passChangeGood = true;
    			}
    			
    			//now check to make sure that there were no mistakes. If there was a mistake, let the user know
    			//and do not update the information at all.
    			if(!emailChangeGood || !usernameChangeGood || !passChangeGood) {
    				out.println("<h2>Some things went wrong:</h2>");
    				
    				if(!emailChangeGood) out.println("<h4>The new email is already associated with another account</h4>");
    				
    				if(!usernameChangeGood) out.println("<h4>The username you tried already exists</h4>");
    				
    				if(!passChangeGood) out.println("<h4>Either your current password was not entered in correctly or the new passwords did not match.</h4>");
    				
    				out.println("<h4>Please correct these and resubmit any changes you would like to make.</h4>");
    				
    			} else {
    				//The first and last name do not need to be unique in the database so who cares about checks?
    				tempUser.setFirstName(firstNameIn);
    				tempUser.setLastName(lastNameIn);
    				
    				tempDAO.updateUser(tempUser);
    				
    				//call the AppUser object constructor with the tempUser as an input parameter so AppUser.user is updated
    				appUser = new AppUser(tempUser);
    			}
    			
    			
    		case "/ProfileChanger": //just print off the normal page
    			printUserInfoPage(out);
    		}
    		
    		
    		makePageBottom(out);
    		
    	} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
    
	private void printUserInfoPage(PrintWriter out) {
		AppUser appUser = new AppUser();
		User u = appUser.getUser();
		
		out.println("<form action=\"/ERS/ChangeMyProfile\">\r\n" + 
				"        <div class=\"box\">\r\n" + 
				"            <label class=\"user_info\">Username:" + u.getUserName() + "</label>\r\n" + 
				"            <input id=\"usernameIn\" name=\"usernameIn\" type=\"text\" value=\"" + u.getUserName() + "\" placeholder=\"new username\" style=\"visibility: hidden; display: none;\"\r\n" + 
				"            />\r\n" + 
				"            <button id=\"buttonA\" type=\"button\" onclick=\"allowChange('usernameIn', 'buttonA')\">change</button>\r\n" + 
				"\r\n" + 
				"            <br/>\r\n" + 
				"\r\n" + 
				"            <label class=\"user_info\">First name: " + u.getFirstName() + "</label>\r\n" + 
				"            <input id=\"firstNameIn\" name=\"firstNameIn\" type=\"text\" value=\"" + u.getFirstName() + "\" placeholder=\"new first name\" style=\"visibility: hidden; display: none;\"\r\n" + 
				"            />\r\n" + 
				"            <button id=\"buttonB\" type=\"button\" onclick=\"allowChange('firstNameIn', 'buttonB')\">change</button>\r\n" + 
				"\r\n" + 
				"            <br/>\r\n" + 
				"\r\n" + 
				"            <label>Last name: " + u.getLastName() + "</label>\r\n" + 
				"            <input id=\"lastNameIn\" name=\"lastNameIn\" type=\"text\" value=\"" + u.getLastName() + "\" placeholder=\"new last name\" style=\"visibility: hidden; display: none;\"\r\n" + 
				"            />\r\n" + 
				"            <button id=\"buttonC\" type=\"button\" onclick=\"allowChange('lastNameIn', 'buttonC')\">change</button>\r\n" + 
				"\r\n" + 
				"            <br/>\r\n" + 
				"\r\n" + 
				"            <label>Email: " + u.getEmail() + "</label>\r\n" + 
				"            <input id=\"emailIn\" name=\"emailIn\" type=\"text\" value=\"" + u.getEmail() + "\" placeholder=\"new email\" style=\"visibility: hidden; display: none;\"\r\n" + 
				"            />\r\n" + 
				"            <button id=\"buttonD\" type=\"button\" onclick=\"allowChange('emailIn', 'buttonD')\">change</button>\r\n" + 
				"\r\n" + 
				"            <br/>\r\n" + 
				"\r\n" + 
				"            <!-- Stuff to change password shall go here!\r\n" + 
				"    Put in one of those check boxes and then have the password change stuff appear when that is checked -->\r\n" + 
				"\r\n" + 
				"            <div ng-init=\"mySwitch = false\">\r\n" + 
				"                <label ng-hide=\"!mySwitch\">Current Password:</label>\r\n" + 
				"                <input name=\"currentPassword\" name=\"currentPassword\" type=\"password\" ng-hide=\"!mySwitch\" style=\"display: inline-block;\" />\r\n" + 
				"                <br ng-hide=\"!mySwitch\" />\r\n" + 
				"                <label ng-hide=\"!mySwitch\">New Password:</label>\r\n" + 
				"                <input name=\"newPassword\" name=\"newPassword\" type=\"password\" ng-hide=\"!mySwitch\" style=\"display: inline-block;\" />\r\n" + 
				"                <br ng-hide=\"!mySwitch\" />\r\n" + 
				"                <label ng-hide=\"!mySwitch\">Confirm :</label>\r\n" + 
				"                <input name=\"confirmNewPassword\" name=\"confirmNewPassword\" type=\"password\" ng-hide=\"!mySwitch\" style=\"display: inline-block;\"\r\n" + 
				"                />\r\n" + 
				"                <br ng-hide=\"!mySwitch\" />\r\n" + 
				"                <input type=\"checkbox\" ng-model=\"mySwitch\" ng-hide=\"mySwitch\" /> Change password </input>\r\n" + 
				"            </div>\r\n" + 
				"\r\n" + 
				"            <br/>\r\n" + 
				"\r\n" + 
				"            <button id=\"commitButton\" type=\"submit\">commit changes</button>\r\n" + 
				"            <!-- you will need to do stuff when this button is clicked -->\r\n" + 
				"        </div>\r\n" + 
				"    </form>\r\n" + 
				"    <script type=\"text/javascript\">\r\n" + 
				"        function allowChange(theId, theButton) {\r\n" + 
				"            document.getElementById(theId).style.display = \"inline-block\";\r\n" + 
				"            document.getElementById(theId).style.visibility = \"visible\";\r\n" + 
				"            document.getElementById(theButton).style.visibility = \"hidden\";\r\n" + 
				"        }\r\n" + 
				"    </script>");
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
