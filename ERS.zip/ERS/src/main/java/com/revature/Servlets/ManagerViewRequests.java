package com.revature.Servlets;

import java.util.List;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.reimbursements.ReimDaoImpl;
import com.revature.reimbursements.Reimbursement;
import com.revature.users.User;
import com.revature.users.UsersDaoImpl;

public class ManagerViewRequests extends ControllerServlet {
	private static final long serialVersionUID = 1L;

	public ManagerViewRequests() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void processRequest(HttpServletRequest req, HttpServletResponse resp, boolean isGet)
			throws ServletException, IOException {
		try (PrintWriter out = resp.getWriter()) {
			String userPath = req.getServletPath();
			ReimDaoImpl reimDao = new ReimDaoImpl();

			makePageTop(out, userPath);
			switch (userPath) {
			case "/ManagerViewRequests":
				makeReimView(out, req, isGet);
				break;
			case "/ManagerViewFilteredRequests":
				makeReimView(out, req, isGet);
				break;
			case "/ManagerUpdateRequest":
				Reimbursement reim = reimDao.readReim(Integer.parseInt(req.getParameter("id")));
				if (req.getParameter("hasAccepted").equals("true")) {
					reim.setStatus(Reimbursement.APPROVED);
				} else {
					reim.setStatus(Reimbursement.DENIED);
				}

				reimDao.updateReim(reim);
				
			}
		}

	}

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, true);

	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, false);
	}

	protected void makeReimView(PrintWriter out, HttpServletRequest req, boolean isGet) {
		ReimDaoImpl reimDao = new ReimDaoImpl();
		UsersDaoImpl userDao = new UsersDaoImpl();

		

		out.println(" <div class=\"box\">\r\n" + "                <h1>Pending requests</h1>\r\n"
				+ "                <table class=\"prettyTable\">\r\n" + "");
		if (req.getServletPath().equals("/ManagerViewFilteredRequests")) {
			User user = new User();
			user.setId(Integer.parseInt(req.getParameter("id")));
			List<Reimbursement> reimsPending = reimDao.readAllUserPending(Integer.parseInt(req.getParameter("id")));
			List<Reimbursement> reimsResolved = reimDao.readAllUserResolved(Integer.parseInt(req.getParameter("id")));
			for(Reimbursement reim :reimsPending) {
				out.println(" <tr>\r\n" + "						<th><a href = \"/ManagerViewFilteredRequests?id="
						+ user.getId() + "\">" + user.getFirstName() + " " + user.getLastName() + "</a></th>\r\n"
						+ "                        <th>" + reim.getAmount() + " </th>\r\n"
						+ "                        <th>" + reim.getType() + "</th>\r\n" + "                        <th>"
						+ reim.getSubmit() + "</th>\r\n" + "						<th>" + reim.getDescription()
						+ "</th>						\r\n"
						+ "						<th><a href=\"PICTURE.jpg\" target=\"_blank\">Click to view receipt</a></th>\r\n"
						+ "						<a href=\"/ManagerUpdateRequest?id=" + reim.getId()
						+ "&hasAccepted=true\" name=\"acceptButton\" >Accept</a>\r\n	"
						+ "						<a href=\"/ManagerUpdateRequest?id=" + reim.getId()
						+ "&hasAccepted=false\"	name=\"declineButton\">Decline</a>\r\n " + "                    </tr>");
			
			}
			
			for (Reimbursement reim: reimsResolved) {
				User resolver = new User();
				
				List<User> possibleResolvers = userDao.readAllUsers();
				resolver.setId(reim.getResolver());
				for (User posResolver : possibleResolvers) {
					if (resolver.getId() == posResolver.getId()) {
						resolver.setFirstName(posResolver.getFirstName());
						resolver.setLastName(posResolver.getLastName());
					}
				}

				out.println(" <tr>\r\n" + "						<th>" + user.getFirstName() + " "
						+ user.getLastName() + "</TH>\r\n" + "                        <th>" + reim.getAmount()
						+ " </th>\r\n" + "                        <th>" + reim.getType() + "</th>\r\n"
						+ "                        <th>" + reim.getSubmit() + "</th>\r\n"
						+ "                        <th>" + reim.getResolve() + " time</th>\r\n"
						+ "                        <th>" + resolver.getFirstName() + " " + resolver.getLastName()
						+ "</th>\r\n" + "						<th>" + reim.getDescription()
						+ "</th>						\r\n"
						+ "						<th><a href=\"PICTURE.jpg\" target=\"_blank\">Click to view receipt</a></th>\r\n"
						+ "                    </tr>");

			}

			out.println("               </table>\r\n" + "            </div>\r\n" + "         <!--</div>-->\r\n"
					+ "		<!--</section>-->\r\n" + "			\r\n" + "</body> \r\n" + "\r\n" + "</html>");
		
			
			
		} else if (req.getServletPath().equals("/ManagerViewRequests")) {
			// pending reimbursements are shown first
			List<Reimbursement> reimsPending = reimDao.readAllPending();
			List<Reimbursement> reimsResolved = reimDao.readAllResolved();
			for (Reimbursement reim : reimsPending) {

				// assigning author name
				List<User> possibleAuthors = userDao.readAllUsers();
				User author = new User();
				author.setId(reim.getAuthor());
				for (User posAuthor : possibleAuthors) {
					if (author.getId() == posAuthor.getId()) {
						author.setFirstName(posAuthor.getFirstName());
						author.setLastName(posAuthor.getLastName());
					}
				}

				out.println(" <tr>\r\n" + "						<th><a href = \"/ManagerViewFilteredRequests?id="
						+ author.getId() + "\">" + author.getFirstName() + " " + author.getLastName() + "</a></th>\r\n"
						+ "                        <th>" + reim.getAmount() + " </th>\r\n"
						+ "                        <th>" + reim.getType() + "</th>\r\n" + "                        <th>"
						+ reim.getSubmit() + "</th>\r\n" + "						<th>" + reim.getDescription()
						+ "</th>						\r\n"
						+ "						<th><a href=\"PICTURE.jpg\" target=\"_blank\">Click to view receipt</a></th>\r\n"
						+ "						<a href=\"/ManagerUpdateRequest?id=" + reim.getId()
						+ "&hasAccepted=true\" name=\"acceptButton\" >Accept</a>\r\n	"
						+ "						<a href=\"/ManagerUpdateRequest?id=" + reim.getId()
						+ "&hasAccepted=false\"	name=\"declineButton\">Decline</a>\r\n " + "                    </tr>");
			}

			for (Reimbursement reim : reimsResolved) {

				List<User> possibleAuthors = userDao.readAllUsers();
				User author = new User();

				author.setId(reim.getAuthor());
				for (User posAuthor : possibleAuthors) {
					if (author.getId() == posAuthor.getId()) {
						author.setFirstName(posAuthor.getFirstName());
						author.setLastName(posAuthor.getLastName());
					}
				}

				User resolver = new User();

				resolver.setId(reim.getResolver());
				for (User posResolver : possibleAuthors) {
					if (resolver.getId() == posResolver.getId()) {
						resolver.setFirstName(posResolver.getFirstName());
						resolver.setLastName(posResolver.getLastName());
					}
				}

				out.println(" <tr>\r\n" + "						<th>" + author.getFirstName() + " "
						+ author.getLastName() + "</TH>\r\n" + "                        <th>" + reim.getAmount()
						+ " </th>\r\n" + "                        <th>" + reim.getType() + "</th>\r\n"
						+ "                        <th>" + reim.getSubmit() + "</th>\r\n"
						+ "                        <th>" + reim.getResolve() + " time</th>\r\n"
						+ "                        <th>" + resolver.getFirstName() + " " + resolver.getLastName()
						+ "</th>\r\n" + "						<th>" + reim.getDescription()
						+ "</th>						\r\n"
						+ "						<th><a href=\"PICTURE.jpg\" target=\"_blank\">Click to view receipt</a></th>\r\n"
						+ "                    </tr>");

			}

			out.println("               </table>\r\n" + "            </div>\r\n" + "         <!--</div>-->\r\n"
					+ "		<!--</section>-->\r\n" + "			\r\n" + "</body> \r\n" + "\r\n" + "</html>");
		}
	}
}
