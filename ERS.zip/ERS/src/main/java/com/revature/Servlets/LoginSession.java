package com.revature.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.users.AppUser;
import com.revature.users.User;
import com.revature.users.UsersDaoImpl;

/**
 * Servlet implementation class LoginSession
 */
public class LoginSession extends ControllerServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginSession() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    /* handled url patterns:
     * x/LoginSession - printing the normal login page
     * x/LogUserIn - the page that will take the information from the LoginSession page and try to log the user in
     * x/RegisterHere - the page that prints for letting new users register an account
     * x/RegisterNewUser - takes the information from the RegisterUser page and tries to make a new user
     * x/LogUserOut - logs the user out then proceeds to give them the normal login screen
     * */
    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
    	try (PrintWriter out = resp.getWriter()) {
    		String userPath = req.getServletPath();
    		AppUser appUser = new AppUser();
    		User user = appUser.getUser();
    		
    		UsersDaoImpl tempDAO = new UsersDaoImpl();
    		
    		makePageTop(out, userPath);
    		
    		switch(userPath) {
    		case "/LoginSession": //the normal login page
    			printLoginPage(out);
    			break;
    		case "/LogUserIn": //try to log the user in and if it does not work, give the login page again with an error at the top
    			if(!tempDAO.attemptLogin(req.getParameter("UserName"), req.getParameter("Password"))) {
    				out.println("<h1>The username and password you entered either do not match or do not exist.</h1>");
    				out.println("<h2>If you need to create a new account, please see the registration page!</h2>");
    				printLoginPage(out);
    			}
    			user = appUser.getUser(); // refresh the user information
    			if(user.getUr_id() == User.EMPLOYEE) {
    				req.getRequestDispatcher("/employeeHome").forward(req, resp);
    			} else if(user.getUr_id() == User.MANAGER) {
    				req.getRequestDispatcher("/managerHome").forward(req, resp);
    			} else {
    				System.out.println("STUFF WENT WRONG! The user was logged in but the Ur_id crap didn't work right!");
    			}
    			break;
    		case "LogUserOut": //logout the user and then give them the login page
    			appUser.logout();
    			printLoginPage(out);
    			break;
    		case "/RegisterHere": //page for registering new users
    			makeRegistrationPage(out, req, resp);
    			break;
    		case "/RegisterNewUser": /*check to see if the username exists, check to see if the passwords
    			* matched, and then redirect if the user is successfully created
    			* if those do not work, messages are shown saying what went wrong and the rest of the registration
    			* page is printed off*/
    			handleRegistrationCheck(out, req, resp, true);
    		}
    		
    		
    		makePageBottom(out);
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
	}
    
	private void handleRegistrationCheck(PrintWriter out, HttpServletRequest req, HttpServletResponse resp, boolean doCheck) throws IOException, ServletException {
		/* Required checks: 
		 * email is unique 
		 * username is unique
		 * passwords match */
		UsersDaoImpl tempDAO = new UsersDaoImpl();
		
		//TODO: Possibly write a check to make sure that the password is not empty
		boolean uniqueEmail = false;
		boolean uniqueUsername = false;
		boolean passwordsMatch = false;
		
		if(doCheck) {
			uniqueEmail = !tempDAO.doesExist(req.getParameter("emailIn"), tempDAO.EMAIL);
			uniqueUsername = !tempDAO.doesExist(req.getParameter("usernameIn"), tempDAO.USERNAME);
			passwordsMatch = req.getParameter("passIn").equals(req.getParameter("conPassIn"));
			if(uniqueEmail && uniqueUsername && passwordsMatch) {
				//make the user, log the user in, and then redirect them to the employee homepage
				User u = new User();
				u.setEmail(req.getParameter("emailIn"));
				u.setUserName(req.getParameter("usernameIn"));
				u.setPassword(req.getParameter("passIn"));
				u.setFirstName(req.getParameter("firstNameIn"));
				u.setLastName(req.getParameter("lastNameIn"));
				u.setUr_id(User.EMPLOYEE);
				tempDAO.createUser(u);
				req.getRequestDispatcher("/employeeHome").forward(req, resp);
			}
		}
		
		out.println(
				"						<form method=\"post\" action=\"/ERS/RegisterNewUser\">\r\n" +
				"<div class=\"box\">\r\n" + 
				"		<div class=\"content\">\r\n" + 
				"\r\n" + 
				"			<h1> Create a new profile!</h1>\r\n" + 
				"\r\n" + 
				"			<div class=\"row\">\r\n" + 
				"				<div class=\"text-center col-md-5\">\r\n" + 
				"					<div class=\"col-md-5 col-md-offset-2\">\r\n" + 
				"						<label class=\"user_info\"> Email: </label>\r\n" + 
				"						<input name=\"emailIn\" type=\"text\" />");
		
		//make sure that the email was unique
		if(doCheck && !uniqueEmail) {
			out.println("<h3 style=\"color:#ff0000\">This email is already associated with an account.</h3>");
		}
		
		out.println("</div>\r\n" + 
				"				</div>\r\n" + 
				"			</div>\r\n" + 
				"\r\n" + 
				"			</br>\r\n" + 
				"\r\n" + 
				"			<div class=\"row\">\r\n" + 
				"				<div class=\"text-center col-md-5\">\r\n" + 
				"					<div class=\"col-md-5 col-md-offset-2\">\r\n" + 
				"						<label class=\"user_info\">Username: </label>\r\n" + 
				"						<input name=\"usernameIn\" class=\"user_info\" type=\"text\" />");
		
		if(doCheck && !uniqueUsername) {
			out.println("<h3 style=\"color:#ff0000\">The username you tried already exists.</h3>");
		}
		
		out.println("</div>\r\n" + 
				"				</div>\r\n" + 
				"				</br>\r\n" + 
				"				<div class=\"row\">\r\n" + 
				"					<div class=\"text-center col-md-5\">\r\n" + 
				"						<div class=\"col-md-5 col-md-offset-2\">\r\n" + 
				"							<label class=\"user_info\">Password: </label>\r\n" + 
				"							<input name=\"passIn\" class=\"user_info\" type=\"password\" />\r\n" + 
				"						</div>\r\n" + 
				"					</div>\r\n" + 
				"					</br>\r\n" + 
				"\r\n" + 
				"					<div class=\"row\">\r\n" + 
				"						<div class=\"text-center col-md-5\">\r\n" + 
				"							<div class=\"col-md-5 col-md-offset-2\">\r\n" + 
				"								<label class=\"user_info\">Confirm Password:  </label>\r\n" + 
				"								<input name=\"conPassIn\" class=\"user_info\" type=\"password\" />");
		
		if(doCheck && !passwordsMatch) {
			//TODO: Possibly write a check to make sure that the password is not empty
			out.println("<h3 style=\"color:#ff0000\">The passwords you entered do not match.</h3>");
		}
		
		out.println("</div>\r\n" + 
				"						</div>\r\n" + 
				"						</br>\r\n" + 
				"\r\n" + 
				"						<div class=\"row\">\r\n" + 
				"							<div class=\"text-center col-md-5\">\r\n" + 
				"								<div class=\"col-md-5 col-md-offset-2\">\r\n" + 
				"									<label class=\"user_info\">First Name: </label>\r\n" + 
				"									<input name=\"firstNameIn\" class=\"user_info\" type=\"text\" />\r\n" + 
				"								</div>\r\n" + 
				"							</div>\r\n" + 
				"							</br>\r\n" + 
				"							<div class=\"row\">\r\n" + 
				"								<div class=\"text-center col-md-5\">\r\n" + 
				"									<div class=\"col-md-5 col-md-offset-2\">\r\n" + 
				"										<label class=\"user_info\">Last Name: </label>\r\n" + 
				"										<input name=\"lastNameIn\" class=\"user_info\" type=\"text\" />\r\n" + 
				"									</div>\r\n" + 
				"								</div>\r\n" + 
				"								</br>\r\n" + 
				"\r\n" + 
				"								</br>\r\n" + 
				"							</div>\r\n" + 
				"						</div>\r\n" + 
				"\r\n" + 
				"							<button id=\"create\" type=\"submit\">Create new profile</button>\r\n" + 
				"\r\n" + 
				"					</div>\r\n" + 
				"				</div>\r\n" + 
				"			</div>\r\n" + 
				"		</div>\r\n" + 
				"	</div>" +
				"						</form>" );
		
	}

	private void makeRegistrationPage(PrintWriter out, HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		handleRegistrationCheck(out, req, resp, false);
		
	}

	private void printLoginPage(PrintWriter out) {
		out.println("<div class=\"video\">\r\n" + 
				"        <div id=\"box1\" class=\"box tinted\">\r\n" + 
				"            <form method=\"POST\" action=\"/ERS/LogUserIn\">\r\n" + 
				"                <div class=\"content\">\r\n" + 
				"                    <h1>Login</h1>\r\n" + 
				"                    <Label>User name</Label>\r\n" + 
				"                    <input name=\"UserName\" />\r\n" + 
				"\r\n" + 
				"                    <br></br>\r\n" + 
				"\r\n" + 
				"                    <Label>Password</Label>\r\n" + 
				"                    <input name=\"Password\" type=\"Password\" />\r\n" + 
				"\r\n" + 
				"                    <br></br>\r\n" + 
				"\r\n" + 
				"                    <div class=\"btn-group btn-group-lg\" role=\"group\" aria-label=\"...\">\r\n" + 
				"                            <label><a href=\"/ERS/RegisterHere\">Register</a></label>\r\n" + 
				"                        <button type=\"submit\" class=\"btn btn-default\">Login</button>\r\n" + 
				"            </form>\r\n" + 
				"            </div>\r\n" + 
				"\r\n" + 
				"            <h2>Style credited to <a href=\"http://ariona.net\" rel=\"follow\" target=\"_blank\">Ariona, Rian</a></h2>\r\n" + 
				"            </div>\r\n" + 
				"\r\n" + 
				"        </div>\r\n" + 
				"    </div>");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	

}
