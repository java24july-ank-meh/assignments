package com.revature.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.driver.OracleDriver;

public class ConnectionUtil {
	public static Connection getConnection() throws SQLException {
		
		OracleDriver driver = new OracleDriver();
		DriverManager.registerDriver(driver);
		String url = "jdbc:oracle:thin:@localhost:1521:xe";

		String username = "RIDB";

		String password = "numb3rs";

		return DriverManager.getConnection(url, username, password);
	}
}
