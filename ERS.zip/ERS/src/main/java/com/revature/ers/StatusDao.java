package com.revature.ers;

public interface StatusDao {
	public void createStatus();
	public void readStatus();
	public void updateStatus();
	public void deleteStatus();
}
