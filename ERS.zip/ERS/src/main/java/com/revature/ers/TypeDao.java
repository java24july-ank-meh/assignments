package com.revature.ers;

public interface TypeDao {
	public void createType (Type t);
	public void readType(Type t);
	public void updateType(Type t);
	public void deleteType(Type t);
}
