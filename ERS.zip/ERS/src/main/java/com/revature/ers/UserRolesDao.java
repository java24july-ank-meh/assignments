package com.revature.ers;

public interface UserRolesDao {
	public void createUserRole(UserRole r);
	public void readUserRole(UserRole r);
	public void updateUserRole(UserRole r);
	public void deleteUserRole(UserRole r);
}
