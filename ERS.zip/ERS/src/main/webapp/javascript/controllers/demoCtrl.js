angular.module('demoApp').controller('demoCtrl', function demoCtro($scope) {
    $scope.firstName = "Nora";
});