$(function() {
            $( "#box" ).draggable();
});