let app = angular.module('profile', []); //Empty brackets for dependencies
app.run(function ($rootScope){
    $rootScope.favoriteColor = 'green';
});